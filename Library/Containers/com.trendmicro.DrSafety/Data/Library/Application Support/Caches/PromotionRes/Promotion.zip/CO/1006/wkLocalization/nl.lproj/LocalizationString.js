var Localization_nl = {
	Product_Description_1: "%@ spambestanden gevonden op uw Mac.",
	Product_Description_2: "Gebruik Cleaner One Pro om schijfruimte vrij te maken",
	Button_Cancel: "Nee, bedankt",
	Button_Download: "Gratis download"
};
