var Localization_de = {
	Product_Description_1: "%@ Junk-Dateien wurden auf Ihrem Mac gefunden.",
	Product_Description_2: "Mit Cleaner One Pro Speicherplatz freigeben",
	Button_Cancel: "Nein danke",
	Button_Download: "Kostenloser Download"
};
