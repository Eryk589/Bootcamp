var Localization_it = {
	Product_Description_1: "%@ di file indesiderati trovato sul Mac.",
	Product_Description_2: "Utilizza Cleaner One Pro per liberare spazio su disco",
	Button_Cancel: "No, grazie",
	Button_Download: "Download gratuito"
};