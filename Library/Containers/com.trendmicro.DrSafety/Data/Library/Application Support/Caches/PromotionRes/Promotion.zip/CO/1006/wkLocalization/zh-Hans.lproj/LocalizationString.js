var Localization_zh_hans = {
	Product_Description_1: "在 Mac 上找到%@的垃圾文件。",
	Product_Description_2: "使用 Cleaner One Pro 可释放磁盘空间",
	Button_Cancel: "不，谢谢",
	Button_Download: "免费下载"
};
