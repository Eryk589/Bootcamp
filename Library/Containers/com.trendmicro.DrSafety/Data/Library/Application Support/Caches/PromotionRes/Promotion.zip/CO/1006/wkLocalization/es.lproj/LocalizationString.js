var Localization_es = {
	Product_Description_1: "Se han encontrado %@ de archivos basura en su Mac.",
	Product_Description_2: "Use Cleaner One Pro para liberar espacio en disco.",
	Button_Cancel: "No, gracias",
	Button_Download: "Descarga gratuita"
};
