var Localization_pt_br = {
	Product_Description_1: "%@ de arquivos de de lixo eletrônico encontrados em seu Mac.",
	Product_Description_2: "Use o Cleaner One Pro para liberar espaço em disco",
	Button_Cancel: "Não, obrigado",
	Button_Download: "Download gratuito"
};
