var Localization_en = {
	Product_Description_1: "%@ of junk files found on your Mac.",
	Product_Description_2: "Use Cleaner One Pro to free up disk space",
	Button_Cancel: "No, thanks",
	Button_Download: "Free download"
};
