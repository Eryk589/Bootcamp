var Localization_fr = {
	Product_Description_1: "%@ fichiers indésirables trouvés sur votre Mac.",
	Product_Description_2: "Utiliser Cleaner One Pro pour libérer de l'espace disque",
	Button_Cancel: "Non merci",
	Button_Download: "Téléchargement gratuit"
};
