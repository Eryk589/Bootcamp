var Localization_zh_hant = {
	Product_Description_1: "在您的 Mac 電腦上發現 %@個殘餘檔案。",
	Product_Description_2: "使用 Cleaner One Pro 即可釋放磁碟空間",
	Button_Cancel: "不了，謝謝",
	Button_Download: "免費下載"
};
