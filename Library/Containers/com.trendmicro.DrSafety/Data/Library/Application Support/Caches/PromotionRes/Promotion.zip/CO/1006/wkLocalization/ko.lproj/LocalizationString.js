var Localization_ko = {
	Product_Description_1: "%@개의 정크 파일이 Mac에서 발견되었습니다.",
	Product_Description_2: "Cleaner One Pro를 사용하여 디스크 공간 비우기",
	Button_Cancel: "아니요",
	Button_Download: "무료 다운로드"
};
