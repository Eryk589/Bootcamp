var Localization_ru = {
	Product_Description_1: "%@ ненужных файлов найдено на вашем компьютере Mac.",
	Product_Description_2: "Воспользуйтесь приложением Cleaner One Pro, чтобы освободить место на диске.",
	Button_Cancel: "Нет, спасибо",
	Button_Download: "Бесплатная загрузка"
};
